<?php

$con = mysqli_connect("localhost","root"," ","tutorial")or die ("couldn't connect");
?>