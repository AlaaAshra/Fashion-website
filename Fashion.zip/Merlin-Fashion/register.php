<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:300" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Chivo:300,700|Playfair+Display:700i" rel="stylesheet">
    <link rel="stylesheet" href="css/style_index.css">
    <link rel="stylesheet" href="css/demo.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/categories.css">
    <link rel="stylesheet" href="css/login.css">
    
</head>
<body style="background-color: #ffffff ;">

    <!-- navbar -->
    <nav>
      <div class="logo">
        <h3><a href="merlin.php" class="logo-name">Alaa & Bochra Fashion</a></h3>
      </div>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="">Brands</a><i class="fas fa-caret-down"></i></a>
          <div class="dropdown-menu">
          <ul >
          <li><a href="https://www.zara.com/tr/">Zara</a></li>
          <li><a href="https://www.nike.com/tr/">Nike</a></li>
          <li><a href="https://tr.puma.com/">Puma</a></li>
          <li><a href="https://www.mavi.com/">Mavi</a></li>
          <li><a href="https://www.koton.com/">Koton</a></li>
        </ul> </div></li>
        <li><a href="contact.php">ContactUs</a></li>
        <li><a href="login.php" id="login">Login</a></li>
      </ul>
      <div class="burger">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
    </nav>
	<hr>
     <br>
	 <br>
	 <br>
	 <br>
	 

</header>







<section class="register-form">

    <form action="">
       <center> register here 🦄</center> <br>
         <center><div class="inputBox">
            <span class="fas fa-user"></span>
            Name: <input type="text" name="" placeholder="enter your name" id="">
        </div></center><br>
       <center> <div class="inputBox">
            <span class="fas fa-envelope"></span>
          email: <input type="email" name="" placeholder="enter your email" id="">
        </div></center><br>
        <center><div class="inputBox">
            <span class="fas fa-lock"></span>
         Password: <input type="password" name="" placeholder="enter your password" id="">
        </div></center><br>
       <center> <div class="inputBox">
            <span class="fas fa-lock"></span>
         Confirm Password:  <input type="password" name="" placeholder="confirm your password" id="">
        </div></center><br>
       <center> <input type="submit" value="sign up" class="btn">
     <a href="login.php" class="btn">   already have an account </a></center>
    </form>

</section>







</body>
</html>